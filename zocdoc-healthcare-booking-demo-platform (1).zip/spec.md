# Zocdoc Healthcare Booking Demo Platform

## Overview
A frontend-only demo web application inspired by Zocdoc for educational and pitch purposes. The platform allows patients to find and book appointments with doctors while providing separate dashboards for both user types. The application is localized for the Indian market with INR currency and Indian doctors.

## Design Requirements
- Clean, professional healthcare design with white and blue color palette
- Trust-focused premium UI with smooth transitions and hover animations
- Fully responsive layouts for mobile, tablet, and desktop

## Authentication (Mock Implementation)
- Patient login/signup pages with email and password fields
- Doctor login page with redirect to doctor dashboard
- Client-side mock state management for login simulation and navigation

## Core Pages

### Home Page
- Hero section with headline "Book trusted doctors near you"
- Search functionality with "Doctor/Specialty" and "Location" input fields for Indian cities
- Primary "Find Doctors" call-to-action button

### Doctors Listing Page
- Grid/list display of doctor cards showing:
  - Doctor photo (placeholder images)
  - Indian doctor names, specialty, ratings
  - Accepted insurance badges
  - Next available appointment
  - "Book Appointment" button with INR pricing
- Filter options for Specialty, Rating, Insurance, and Availability
- Location filters for Indian cities (Mumbai, Delhi, Bengaluru, etc.)

### Doctor Profile Page
- Doctor biography and qualifications
- Accepted insurance information
- Patient reviews (mock data)
- Appointment slot selection interface with INR pricing
- "Confirm Booking" button leading to payment simulation

## Payment System (Demo Simulation)
- "Pay for Appointment" modal appearing after appointment slot selection
- Payment form with INR amount display
- Simulated payment success/failure states with responsive messages
- On successful payment, appointment status updates to "Booked" in appointment store
- Payment confirmation with transaction details in INR

## Calendar System (UI Only)
- Patient calendar with monthly and weekly views showing upcoming and past appointments
- Doctor calendar with daily/weekly schedule displaying booked and available slots
- Mock editable availability for doctors

## User Features

### Patient Records
- Appointment history display with payment status and INR amounts
- Mock prescriptions and doctor notes
- Downloadable medical records (UI simulation)

### Insurance Module
- Insurance selection during booking process
- Insurance compatibility indicators on doctor cards and profiles

### Credit/Loyalty System
- Patient credit score and loyalty points display
- Credit increase simulation for completed appointments
- Working cancellation penalty system with INR calculations:
  - >6 hours before appointment: deduct 5 credits from patient balance and 5% of consultation fee from refund
  - Cancellation confirmation dialog showing refund breakdown:
    - Original consultation fee in INR
    - 5% deduction amount in INR
    - Final refund amount in INR
    - Confirmation message: "Canceling will deduct 5 credits and 5% of the fee"
  - Real-time credit balance updates in patient store
  - Appointment status and refund amount updates in appointment store
- Appointment status toggle functionality (booked/cancelled) with proper refund calculations

## Dashboards

### Patient Dashboard
- Upcoming appointments overview with payment status
- Real-time credit score display reflecting cancellation deductions
- Insurance details
- Transaction history with INR amounts including refund breakdowns and credit deductions
- Quick navigation to calendar and records

### Doctor Dashboard
- Today's appointments with payment status
- Weekly schedule view
- Patient list (mock data with Indian names)

## Mock Data Localization
- Indian doctor names and specialties in mock database
- Indian city locations (Mumbai, Delhi, Bengaluru, Chennai, Kolkata, etc.)
- INR currency formatting throughout the application
- Cultural context appropriate for Indian healthcare market

## Additional Pages
- 404 error page with "Page Not Found" message and home navigation
- Clear page breadcrumbs and smooth navigation throughout

## Technical Notes
- Frontend-only implementation with mock data
- No backend integration, payments, or real medical data
- Client-side state management for all user interactions including working credit and refund system
- INR currency display and calculations throughout
- Showcase-ready UX suitable for demonstrations and pitches
- Working credit balance management in patientStore.ts
- Working refund calculations and status updates in appointmentStore.ts
