import { RouterProvider, createRouter, createRoute, createRootRoute } from '@tanstack/react-router';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from './contexts/AuthContext';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import DoctorsListingPage from './pages/DoctorsListingPage';
import DoctorProfilePage from './pages/DoctorProfilePage';
import PatientDashboardPage from './pages/PatientDashboardPage';
import DoctorDashboardPage from './pages/DoctorDashboardPage';
import PatientCalendarPage from './pages/PatientCalendarPage';
import DoctorCalendarPage from './pages/DoctorCalendarPage';
import PatientRecordsPage from './pages/PatientRecordsPage';
import PatientLoginPage from './pages/PatientLoginPage';
import PatientSignupPage from './pages/PatientSignupPage';
import DoctorLoginPage from './pages/DoctorLoginPage';
import NotFoundPage from './pages/NotFoundPage';

const rootRoute = createRootRoute({
  component: Layout,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: HomePage,
});

const doctorsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/doctors',
  component: DoctorsListingPage,
});

const doctorProfileRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/doctors/$doctorId',
  component: DoctorProfilePage,
});

const patientDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/patient/dashboard',
  component: PatientDashboardPage,
});

const patientCalendarRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/patient/calendar',
  component: PatientCalendarPage,
});

const patientRecordsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/patient/records',
  component: PatientRecordsPage,
});

const doctorDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/doctor/dashboard',
  component: DoctorDashboardPage,
});

const doctorCalendarRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/doctor/calendar',
  component: DoctorCalendarPage,
});

const patientLoginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/patient/login',
  component: PatientLoginPage,
});

const patientSignupRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/patient/signup',
  component: PatientSignupPage,
});

const doctorLoginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/doctor/login',
  component: DoctorLoginPage,
});

const notFoundRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '*',
  component: NotFoundPage,
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  doctorsRoute,
  doctorProfileRoute,
  patientDashboardRoute,
  patientCalendarRoute,
  patientRecordsRoute,
  doctorDashboardRoute,
  doctorCalendarRoute,
  patientLoginRoute,
  patientSignupRoute,
  doctorLoginRoute,
  notFoundRoute,
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <AuthProvider>
        <RouterProvider router={router} />
        <Toaster />
      </AuthProvider>
    </ThemeProvider>
  );
}
