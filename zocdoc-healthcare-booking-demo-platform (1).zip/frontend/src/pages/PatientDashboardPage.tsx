import { useEffect } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, FileText, Shield, Award, Clock, MapPin, IndianRupee } from 'lucide-react';
import { useAppointments } from '../lib/appointmentStore';
import { usePatientData } from '../lib/patientStore';
import { format } from 'date-fns';

export default function PatientDashboardPage() {
  const { user, userType } = useAuth();
  const navigate = useNavigate();
  const { appointments } = useAppointments();
  const { credits, insurance } = usePatientData();

  useEffect(() => {
    if (!user || userType !== 'patient') {
      navigate({ to: '/patient/login' });
    }
  }, [user, userType, navigate]);

  const upcomingAppointments = appointments
    .filter((apt) => new Date(apt.date) >= new Date() && apt.status !== 'cancelled')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 3);

  const recentTransactions = appointments
    .filter((apt) => apt.status === 'cancelled' && apt.refundAmount)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 3);

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-3xl font-bold">Welcome back, {user?.name}!</h1>
        <p className="text-muted-foreground">Manage your appointments and health records</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Credit Score</CardTitle>
            <Award className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{credits}</div>
            <p className="text-xs text-muted-foreground">Loyalty points earned</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Insurance</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-semibold">{insurance}</div>
            <p className="text-xs text-muted-foreground">Active coverage</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{upcomingAppointments.length}</div>
            <p className="text-xs text-muted-foreground">Upcoming this month</p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Appointments</CardTitle>
          </CardHeader>
          <CardContent>
            {upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAppointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-start gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/50"
                  >
                    <img
                      src={apt.doctorImage}
                      alt={apt.doctorName}
                      className="h-12 w-12 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <p className="font-semibold">{apt.doctorName}</p>
                      <p className="text-sm text-muted-foreground">{apt.specialty}</p>
                      <div className="mt-2 flex flex-wrap gap-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {format(new Date(apt.date), 'MMM dd, yyyy')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {apt.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {apt.location}
                        </span>
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <Badge variant={apt.status === 'booked' ? 'default' : apt.status === 'pending' ? 'secondary' : 'outline'}>
                          {apt.status}
                        </Badge>
                        {apt.paymentStatus && (
                          <Badge variant={apt.paymentStatus === 'success' ? 'default' : 'destructive'}>
                            {apt.paymentStatus === 'success' ? 'Paid' : 'Payment Failed'}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => navigate({ to: '/patient/calendar' })}>
                  View All Appointments
                </Button>
              </div>
            ) : (
              <div className="py-8 text-center">
                <Calendar className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <p className="mb-4 text-muted-foreground">No upcoming appointments</p>
                <Button onClick={() => navigate({ to: '/doctors' })}>Find a Doctor</Button>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => navigate({ to: '/doctors' })}
              >
                <Calendar className="mr-2 h-4 w-4" />
                Book New Appointment
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => navigate({ to: '/patient/calendar' })}
              >
                <Clock className="mr-2 h-4 w-4" />
                View Calendar
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={() => navigate({ to: '/patient/records' })}
              >
                <FileText className="mr-2 h-4 w-4" />
                Medical Records
              </Button>
            </CardContent>
          </Card>

          {recentTransactions.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Refunds</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentTransactions.map((apt) => (
                    <div
                      key={apt.id}
                      className="flex items-center justify-between rounded-lg border p-3"
                    >
                      <div>
                        <p className="text-sm font-medium">{apt.doctorName}</p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(apt.date), 'MMM dd, yyyy')}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 text-sm font-semibold text-green-600">
                        <IndianRupee className="h-3 w-3" />
                        {apt.refundAmount}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
