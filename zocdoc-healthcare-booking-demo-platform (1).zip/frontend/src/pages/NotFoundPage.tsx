import { useNavigate } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Home } from 'lucide-react';

export default function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <div className="container flex min-h-[calc(100vh-8rem)] flex-col items-center justify-center py-8 text-center">
      <div className="mb-8 text-9xl font-bold text-primary/20">404</div>
      <h1 className="mb-4 text-4xl font-bold">Page Not Found</h1>
      <p className="mb-8 max-w-md text-muted-foreground">
        Sorry, we couldn't find the page you're looking for. It might have been moved or doesn't exist.
      </p>
      <Button onClick={() => navigate({ to: '/' })} size="lg">
        <Home className="mr-2 h-5 w-5" />
        Back to Home
      </Button>
    </div>
  );
}
