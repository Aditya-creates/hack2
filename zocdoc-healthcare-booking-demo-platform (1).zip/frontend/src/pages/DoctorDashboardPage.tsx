import { useEffect } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Users, Clock, TrendingUp } from 'lucide-react';
import { useAppointments } from '../lib/appointmentStore';
import { format, isToday, isThisWeek } from 'date-fns';

export default function DoctorDashboardPage() {
  const { user, userType } = useAuth();
  const navigate = useNavigate();
  const { appointments } = useAppointments();

  useEffect(() => {
    if (!user || userType !== 'doctor') {
      navigate({ to: '/doctor/login' });
    }
  }, [user, userType, navigate]);

  const todayAppointments = appointments.filter((apt) => 
    isToday(new Date(apt.date)) && apt.status !== 'cancelled'
  );

  const weekAppointments = appointments.filter((apt) => 
    isThisWeek(new Date(apt.date)) && apt.status !== 'cancelled'
  );

  const totalPatients = new Set(appointments.map(apt => apt.patientName)).size;

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'booked':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'completed':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-3xl font-bold">Doctor Dashboard</h1>
        <p className="text-muted-foreground">Welcome back, Dr. {user?.name}</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Today's Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{todayAppointments.length}</div>
            <p className="text-xs text-muted-foreground">Scheduled for today</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">This Week</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{weekAppointments.length}</div>
            <p className="text-xs text-muted-foreground">Appointments this week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalPatients}</div>
            <p className="text-xs text-muted-foreground">Unique patients</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Rating</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">4.8</div>
            <p className="text-xs text-muted-foreground">Average rating</p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Today's Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            {todayAppointments.length > 0 ? (
              <div className="space-y-4">
                {todayAppointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-start justify-between rounded-lg border p-4"
                  >
                    <div>
                      <p className="font-semibold">{apt.patientName}</p>
                      <p className="text-sm text-muted-foreground">{apt.time}</p>
                      <p className="mt-1 text-xs text-muted-foreground">{apt.reason}</p>
                    </div>
                    <Badge variant={getStatusBadgeVariant(apt.status)}>
                      {apt.status}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground">
                No appointments scheduled for today
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => navigate({ to: '/doctor/calendar' })}
            >
              <Calendar className="mr-2 h-4 w-4" />
              View Full Calendar
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => navigate({ to: '/doctor/calendar' })}
            >
              <Clock className="mr-2 h-4 w-4" />
              Manage Availability
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => navigate({ to: '/doctor/calendar' })}
            >
              <Users className="mr-2 h-4 w-4" />
              Patient List
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
