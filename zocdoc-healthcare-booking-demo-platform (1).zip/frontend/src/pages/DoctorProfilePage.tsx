import { useState } from 'react';
import { useParams, useNavigate } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star, MapPin, GraduationCap, Shield, Calendar } from 'lucide-react';
import { mockDoctors, mockReviews } from '../lib/mockData';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import BookingDialog from '../components/BookingDialog';

export default function DoctorProfilePage() {
  const { doctorId } = useParams({ strict: false });
  const navigate = useNavigate();
  const { isAuthenticated, userType } = useAuth();
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);

  const doctor = mockDoctors.find((d) => d.id === doctorId);

  if (!doctor) {
    return (
      <div className="container py-16 text-center">
        <h1 className="mb-4 text-2xl font-bold">Doctor not found</h1>
        <Button onClick={() => navigate({ to: '/doctors' })}>Back to Doctors</Button>
      </div>
    );
  }

  const doctorReviews = mockReviews.filter((r) => r.doctorId === doctor.id);

  const handleBookAppointment = () => {
    if (!isAuthenticated) {
      toast.error('Please login to book an appointment');
      navigate({ to: '/patient/login' });
      return;
    }
    if (userType !== 'patient') {
      toast.error('Only patients can book appointments');
      return;
    }
    setBookingDialogOpen(true);
  };

  return (
    <div className="container py-8">
      <Button variant="ghost" onClick={() => navigate({ to: '/doctors' })} className="mb-6">
        ← Back to Doctors
      </Button>

      <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col gap-6 md:flex-row">
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="h-40 w-40 rounded-lg object-cover"
                />
                
                <div className="flex-1">
                  <h1 className="mb-2 text-3xl font-bold">{doctor.name}</h1>
                  <p className="mb-3 text-lg text-muted-foreground">{doctor.specialty}</p>
                  
                  <div className="mb-4 flex flex-wrap gap-4">
                    <div className="flex items-center gap-1">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold">{doctor.rating}</span>
                      <span className="text-sm text-muted-foreground">({doctor.reviewCount} reviews)</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <MapPin className="h-5 w-5" />
                      {doctor.location}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">
                      <Calendar className="mr-1 h-3 w-3" />
                      Next: {doctor.nextAvailable}
                    </Badge>
                    <Badge variant="secondary">
                      ₹{doctor.consultationFee} consultation
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="about" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="insurance">Insurance</TabsTrigger>
            </TabsList>

            <TabsContent value="about" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Biography</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{doctor.bio}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="h-5 w-5" />
                    Qualifications
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {doctor.qualifications.map((qual, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary" />
                        <span className="text-muted-foreground">{qual}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews" className="space-y-4">
              {doctorReviews.map((review) => (
                <Card key={review.id}>
                  <CardContent className="p-6">
                    <div className="mb-3 flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>{review.patientName[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{review.patientName}</p>
                          <p className="text-sm text-muted-foreground">{review.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-semibold">{review.rating}</span>
                      </div>
                    </div>
                    <p className="text-muted-foreground">{review.comment}</p>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="insurance">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Accepted Insurance Plans
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {doctor.acceptedInsurance.map((insurance) => (
                      <div
                        key={insurance}
                        className="flex items-center gap-2 rounded-lg border p-3"
                      >
                        <Shield className="h-4 w-4 text-primary" />
                        <span>{insurance}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card className="sticky top-20">
            <CardHeader>
              <CardTitle>Book Appointment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg bg-muted p-4">
                <p className="mb-1 text-sm text-muted-foreground">Consultation Fee</p>
                <p className="text-2xl font-bold">₹{doctor.consultationFee}</p>
              </div>
              
              <div className="rounded-lg bg-muted p-4">
                <p className="mb-1 text-sm text-muted-foreground">Next Available</p>
                <p className="font-semibold">{doctor.nextAvailable}</p>
              </div>

              <Button className="w-full" size="lg" onClick={handleBookAppointment}>
                Book Appointment
              </Button>

              <p className="text-center text-xs text-muted-foreground">
                You can cancel up to 6 hours before your appointment
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <BookingDialog
        open={bookingDialogOpen}
        onOpenChange={setBookingDialogOpen}
        doctor={doctor}
      />
    </div>
  );
}
