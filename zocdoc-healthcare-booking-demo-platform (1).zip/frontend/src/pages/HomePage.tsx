import { useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Search, MapPin, Calendar, Shield, Star, Clock } from 'lucide-react';

export default function HomePage() {
  const navigate = useNavigate();
  const [specialty, setSpecialty] = useState('');
  const [location, setLocation] = useState('');

  const handleSearch = () => {
    navigate({ to: '/doctors', search: { specialty, location } });
  };

  const features = [
    {
      icon: Calendar,
      title: 'Easy Booking',
      description: 'Book appointments with top-rated doctors in just a few clicks',
    },
    {
      icon: Shield,
      title: 'Insurance Accepted',
      description: 'Find doctors who accept your insurance plan',
    },
    {
      icon: Star,
      title: 'Verified Reviews',
      description: 'Read authentic reviews from real patients',
    },
    {
      icon: Clock,
      title: 'Same-Day Appointments',
      description: 'Get care when you need it with available slots today',
    },
  ];

  const specialties = [
    'Primary Care',
    'Dentist',
    'Dermatologist',
    'Cardiologist',
    'Pediatrician',
    'Orthopedist',
  ];

  return (
    <div className="flex flex-col">
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-accent/5 py-20 md:py-32">
        <div className="container relative z-10">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="mb-6 text-4xl font-bold tracking-tight text-foreground md:text-6xl">
              Book trusted doctors near you
            </h1>
            <p className="mb-8 text-lg text-muted-foreground md:text-xl">
              Find and book appointments with verified healthcare professionals in your area
            </p>

            <Card className="mx-auto max-w-2xl shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col gap-4 md:flex-row">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Doctor / Specialty"
                      value={specialty}
                      onChange={(e) => setSpecialty(e.target.value)}
                      className="pl-10"
                      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    />
                  </div>
                  <div className="relative flex-1">
                    <MapPin className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Location"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="pl-10"
                      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    />
                  </div>
                  <Button onClick={handleSearch} size="lg" className="md:w-auto">
                    Find Doctors
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="mb-12 text-center text-3xl font-bold">Why Choose Zocdoc?</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <Card key={index} className="transition-all hover:shadow-md">
                <CardContent className="p-6">
                  <div className="mb-4 inline-flex rounded-lg bg-primary/10 p-3">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-muted/30 py-16 md:py-24">
        <div className="container">
          <h2 className="mb-12 text-center text-3xl font-bold">Popular Specialties</h2>
          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
            {specialties.map((spec) => (
              <Button
                key={spec}
                variant="outline"
                className="h-auto py-4 transition-all hover:border-primary hover:bg-primary/5"
                onClick={() => navigate({ to: '/doctors', search: { specialty: spec } })}
              >
                {spec}
              </Button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
