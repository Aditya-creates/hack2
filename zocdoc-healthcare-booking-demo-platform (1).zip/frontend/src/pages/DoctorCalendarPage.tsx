import { useEffect, useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar as CalendarIcon, Clock } from 'lucide-react';
import { useAppointments } from '../lib/appointmentStore';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, isToday, addWeeks, subWeeks } from 'date-fns';

export default function DoctorCalendarPage() {
  const { user, userType } = useAuth();
  const navigate = useNavigate();
  const { appointments } = useAppointments();
  const [selectedDate, setSelectedDate] = useState(new Date());

  useEffect(() => {
    if (!user || userType !== 'doctor') {
      navigate({ to: '/doctor/login' });
    }
  }, [user, userType, navigate]);

  const weekStart = startOfWeek(selectedDate);
  const weekEnd = endOfWeek(selectedDate);
  const daysInWeek = eachDayOfInterval({ start: weekStart, end: weekEnd });

  const timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
  ];

  const todayAppointments = appointments
    .filter((apt) => isSameDay(new Date(apt.date), new Date()) && apt.status !== 'cancelled')
    .sort((a, b) => a.time.localeCompare(b.time));

  const getAppointmentForSlot = (day: Date, time: string) => {
    return appointments.find(
      (apt) => isSameDay(new Date(apt.date), day) && apt.time === time && apt.status !== 'cancelled'
    );
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'booked':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'completed':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-3xl font-bold">Doctor Calendar</h1>
        <p className="text-muted-foreground">Manage your schedule and availability</p>
      </div>

      <Tabs defaultValue="week" className="space-y-6">
        <TabsList>
          <TabsTrigger value="week">Week View</TabsTrigger>
          <TabsTrigger value="day">Today</TabsTrigger>
        </TabsList>

        <TabsContent value="week" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Week of {format(weekStart, 'MMM dd, yyyy')}</span>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDate(subWeeks(selectedDate, 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDate(new Date())}
                  >
                    This Week
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDate(addWeeks(selectedDate, 1))}
                  >
                    Next
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <div className="min-w-[800px]">
                  <div className="grid grid-cols-8 gap-2">
                    <div className="p-2" />
                    {daysInWeek.map((day) => (
                      <div
                        key={day.toISOString()}
                        className={`p-2 text-center ${isToday(day) ? 'rounded-lg bg-primary/10' : ''}`}
                      >
                        <div className="text-sm font-semibold">{format(day, 'EEE')}</div>
                        <div className="text-lg font-bold">{format(day, 'd')}</div>
                      </div>
                    ))}
                  </div>

                  {timeSlots.map((time) => (
                    <div key={time} className="grid grid-cols-8 gap-2 border-t py-2">
                      <div className="p-2 text-sm font-medium text-muted-foreground">{time}</div>
                      {daysInWeek.map((day) => {
                        const appointment = getAppointmentForSlot(day, time);
                        return (
                          <div
                            key={`${day.toISOString()}-${time}`}
                            className={`min-h-[60px] rounded-lg border p-2 ${
                              appointment
                                ? 'border-primary bg-primary/10'
                                : 'border-dashed hover:bg-muted/50'
                            }`}
                          >
                            {appointment && (
                              <div className="text-xs">
                                <p className="font-semibold">{appointment.patientName}</p>
                                <p className="text-muted-foreground">{appointment.reason}</p>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="day" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Today's Schedule - {format(new Date(), 'MMMM dd, yyyy')}</CardTitle>
            </CardHeader>
            <CardContent>
              {todayAppointments.length > 0 ? (
                <div className="space-y-4">
                  {todayAppointments.map((apt) => (
                    <div
                      key={apt.id}
                      className="flex items-start justify-between rounded-lg border p-4"
                    >
                      <div className="flex gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                          <Clock className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold">{apt.patientName}</p>
                          <p className="text-sm text-muted-foreground">{apt.time}</p>
                          <p className="mt-1 text-sm text-muted-foreground">Reason: {apt.reason}</p>
                          {apt.insurance && (
                            <p className="mt-1 text-xs text-muted-foreground">Insurance: {apt.insurance}</p>
                          )}
                        </div>
                      </div>
                      <Badge variant={getStatusBadgeVariant(apt.status)}>
                        {apt.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center text-muted-foreground">
                  No appointments scheduled for today
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
