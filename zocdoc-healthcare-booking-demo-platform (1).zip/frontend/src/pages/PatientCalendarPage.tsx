import { useEffect, useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar as CalendarIcon, Clock, MapPin, IndianRupee } from 'lucide-react';
import { useAppointments } from '../lib/appointmentStore';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, isPast } from 'date-fns';
import CancelAppointmentDialog from '../components/CancelAppointmentDialog';

export default function PatientCalendarPage() {
  const { user, userType } = useAuth();
  const navigate = useNavigate();
  const { appointments } = useAppointments();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<string | null>(null);

  useEffect(() => {
    if (!user || userType !== 'patient') {
      navigate({ to: '/patient/login' });
    }
  }, [user, userType, navigate]);

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const upcomingAppointments = appointments
    .filter((apt) => new Date(apt.date) >= new Date() && apt.status !== 'cancelled')
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const pastAppointments = appointments
    .filter((apt) => new Date(apt.date) < new Date() || apt.status === 'cancelled')
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const appointmentsOnDate = (date: Date) => {
    return appointments.filter((apt) => isSameDay(new Date(apt.date), date) && apt.status !== 'cancelled');
  };

  const handleCancelClick = (appointmentId: string) => {
    setSelectedAppointment(appointmentId);
    setCancelDialogOpen(true);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'booked':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'cancelled':
        return 'destructive';
      case 'completed':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="mb-2 text-3xl font-bold">My Calendar</h1>
        <p className="text-muted-foreground">View and manage your appointments</p>
      </div>

      <Tabs defaultValue="calendar" className="space-y-6">
        <TabsList>
          <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="past">Past</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{format(selectedDate, 'MMMM yyyy')}</span>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() - 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDate(new Date())}
                  >
                    Today
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedDate(new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1))}
                  >
                    Next
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                  <div key={day} className="p-2 text-center text-sm font-semibold text-muted-foreground">
                    {day}
                  </div>
                ))}
                {Array.from({ length: monthStart.getDay() }).map((_, i) => (
                  <div key={`empty-${i}`} />
                ))}
                {daysInMonth.map((day) => {
                  const dayAppointments = appointmentsOnDate(day);
                  const hasAppointments = dayAppointments.length > 0;
                  
                  return (
                    <div
                      key={day.toISOString()}
                      className={`min-h-[80px] rounded-lg border p-2 transition-colors ${
                        isToday(day) ? 'border-primary bg-primary/5' : ''
                      } ${isPast(day) && !isToday(day) ? 'bg-muted/30' : ''} ${
                        hasAppointments ? 'cursor-pointer hover:bg-muted/50' : ''
                      }`}
                    >
                      <div className="text-sm font-medium">{format(day, 'd')}</div>
                      {hasAppointments && (
                        <div className="mt-1 space-y-1">
                          {dayAppointments.slice(0, 2).map((apt) => (
                            <div
                              key={apt.id}
                              className="truncate rounded bg-primary/10 px-1 py-0.5 text-xs text-primary"
                            >
                              {apt.time}
                            </div>
                          ))}
                          {dayAppointments.length > 2 && (
                            <div className="text-xs text-muted-foreground">
                              +{dayAppointments.length - 2} more
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming" className="space-y-4">
          {upcomingAppointments.length > 0 ? (
            upcomingAppointments.map((apt) => (
              <Card key={apt.id}>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                    <div className="flex gap-4">
                      <img
                        src={apt.doctorImage}
                        alt={apt.doctorName}
                        className="h-16 w-16 rounded-lg object-cover"
                      />
                      <div>
                        <h3 className="font-semibold">{apt.doctorName}</h3>
                        <p className="text-sm text-muted-foreground">{apt.specialty}</p>
                        <div className="mt-2 flex flex-wrap gap-3 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <CalendarIcon className="h-4 w-4" />
                            {format(new Date(apt.date), 'MMM dd, yyyy')}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {apt.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {apt.location}
                          </span>
                        </div>
                        {apt.reason && (
                          <p className="mt-2 text-sm text-muted-foreground">Reason: {apt.reason}</p>
                        )}
                        <div className="mt-2 flex items-center gap-1 text-sm font-semibold">
                          <IndianRupee className="h-3 w-3" />
                          {apt.fee}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Badge variant={getStatusBadgeVariant(apt.status)}>
                        {apt.status}
                      </Badge>
                      {apt.paymentStatus && (
                        <Badge variant={apt.paymentStatus === 'success' ? 'default' : 'destructive'}>
                          {apt.paymentStatus === 'success' ? 'Paid' : 'Payment Failed'}
                        </Badge>
                      )}
                      {apt.status === 'booked' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCancelClick(apt.id)}
                        >
                          Cancel
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <CalendarIcon className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <p className="mb-4 text-muted-foreground">No upcoming appointments</p>
                <Button onClick={() => navigate({ to: '/doctors' })}>Book an Appointment</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="past" className="space-y-4">
          {pastAppointments.length > 0 ? (
            pastAppointments.map((apt) => (
              <Card key={apt.id} className="opacity-75">
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                    <div className="flex gap-4">
                      <img
                        src={apt.doctorImage}
                        alt={apt.doctorName}
                        className="h-16 w-16 rounded-lg object-cover"
                      />
                      <div>
                        <h3 className="font-semibold">{apt.doctorName}</h3>
                        <p className="text-sm text-muted-foreground">{apt.specialty}</p>
                        <div className="mt-2 flex flex-wrap gap-3 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <CalendarIcon className="h-4 w-4" />
                            {format(new Date(apt.date), 'MMM dd, yyyy')}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {apt.time}
                          </span>
                        </div>
                        {apt.refundAmount && (
                          <div className="mt-2 flex items-center gap-1 text-sm font-semibold text-green-600">
                            <span>Refund:</span>
                            <IndianRupee className="h-3 w-3" />
                            {apt.refundAmount}
                          </div>
                        )}
                      </div>
                    </div>
                    <Badge variant={getStatusBadgeVariant(apt.status)}>
                      {apt.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                No past appointments
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      <CancelAppointmentDialog
        open={cancelDialogOpen}
        onOpenChange={setCancelDialogOpen}
        appointmentId={selectedAppointment}
      />
    </div>
  );
}
