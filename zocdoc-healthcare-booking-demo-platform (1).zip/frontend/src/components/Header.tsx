import { Link, useNavigate } from '@tanstack/react-router';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Calendar, FileText, LayoutDashboard, LogOut, Menu, Stethoscope, User } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useState } from 'react';

export default function Header() {
  const { user, userType, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate({ to: '/' });
  };

  const patientLinks = [
    { to: '/patient/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/patient/calendar', label: 'Calendar', icon: Calendar },
    { to: '/patient/records', label: 'Records', icon: FileText },
  ];

  const doctorLinks = [
    { to: '/doctor/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/doctor/calendar', label: 'Calendar', icon: Calendar },
  ];

  const links = userType === 'patient' ? patientLinks : userType === 'doctor' ? doctorLinks : [];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2 transition-opacity hover:opacity-80">
            <Stethoscope className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold text-primary">Zocdoc</span>
          </Link>

          <nav className="hidden items-center gap-6 md:flex">
            <Link
              to="/doctors"
              className="text-sm font-medium text-foreground/80 transition-colors hover:text-primary"
            >
              Find Doctors
            </Link>
            {isAuthenticated && links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="text-sm font-medium text-foreground/80 transition-colors hover:text-primary"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="hidden md:flex">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  {links.map((link) => (
                    <DropdownMenuItem key={link.to} onClick={() => navigate({ to: link.to })}>
                      <link.icon className="mr-2 h-4 w-4" />
                      {link.label}
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col gap-4 pt-8">
                    <div className="border-b pb-4">
                      <p className="text-sm font-medium">{user?.name}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                    <Link
                      to="/doctors"
                      className="text-sm font-medium"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Find Doctors
                    </Link>
                    {links.map((link) => (
                      <Link
                        key={link.to}
                        to={link.to}
                        className="flex items-center gap-2 text-sm font-medium"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        <link.icon className="h-4 w-4" />
                        {link.label}
                      </Link>
                    ))}
                    <Button variant="outline" onClick={handleLogout} className="mt-4">
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          ) : (
            <>
              <div className="hidden items-center gap-2 md:flex">
                <Button variant="ghost" asChild>
                  <Link to="/patient/login">Patient Login</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link to="/doctor/login">Doctor Login</Link>
                </Button>
                <Button asChild>
                  <Link to="/patient/signup">Sign Up</Link>
                </Button>
              </div>

              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col gap-4 pt-8">
                    <Link
                      to="/doctors"
                      className="text-sm font-medium"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Find Doctors
                    </Link>
                    <Button variant="ghost" asChild onClick={() => setMobileMenuOpen(false)}>
                      <Link to="/patient/login">Patient Login</Link>
                    </Button>
                    <Button variant="outline" asChild onClick={() => setMobileMenuOpen(false)}>
                      <Link to="/doctor/login">Doctor Login</Link>
                    </Button>
                    <Button asChild onClick={() => setMobileMenuOpen(false)}>
                      <Link to="/patient/signup">Sign Up</Link>
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
