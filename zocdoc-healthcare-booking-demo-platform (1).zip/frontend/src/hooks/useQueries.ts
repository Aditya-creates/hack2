// This file is intentionally empty as the backend is not implemented
// All data is managed through client-side stores (appointmentStore, patientStore)
// and mock data (mockData.ts)
