export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  rating: number;
  reviewCount: number;
  location: string;
  nextAvailable: string;
  acceptedInsurance: string[];
  image: string;
  bio: string;
  qualifications: string[];
  consultationFee: number;
}

export interface Review {
  id: string;
  doctorId: string;
  patientName: string;
  rating: number;
  comment: string;
  date: string;
}

export const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Priya Sharma',
    specialty: 'Primary Care',
    rating: 4.9,
    reviewCount: 234,
    location: 'Mumbai, Maharashtra',
    nextAvailable: 'Today at 2:00 PM',
    acceptedInsurance: ['Star Health', 'ICICI Lombard', 'HDFC ERGO', 'Max Bupa'],
    image: '/assets/generated/doctor-female-1.dim_300x300.png',
    bio: 'Dr. Sharma is a board-certified family medicine physician with over 15 years of experience. She specializes in preventive care, chronic disease management, and wellness counseling.',
    qualifications: [
      'MBBS from Grant Medical College, Mumbai',
      'MD in Family Medicine from AIIMS, Delhi',
      'Member of Indian Medical Association',
      'Fellow of the Academy of Family Physicians of India',
    ],
    consultationFee: 800,
  },
  {
    id: '2',
    name: 'Dr. Rajesh Kumar',
    specialty: 'Cardiologist',
    rating: 4.8,
    reviewCount: 189,
    location: 'Bengaluru, Karnataka',
    nextAvailable: 'Tomorrow at 10:00 AM',
    acceptedInsurance: ['Star Health', 'Religare', 'ICICI Lombard', 'Max Bupa'],
    image: '/assets/generated/doctor-male-cardio.dim_300x300.png',
    bio: 'Dr. Kumar is a renowned cardiologist specializing in interventional cardiology and heart disease prevention. He has published numerous research papers on cardiovascular health.',
    qualifications: [
      'MBBS from Maulana Azad Medical College, Delhi',
      'DM in Cardiology from PGIMER, Chandigarh',
      'Member of Cardiological Society of India',
      'Fellow of American College of Cardiology',
    ],
    consultationFee: 1500,
  },
  {
    id: '3',
    name: 'Dr. Anjali Desai',
    specialty: 'Pediatrician',
    rating: 4.9,
    reviewCount: 312,
    location: 'Delhi, NCR',
    nextAvailable: 'Today at 4:00 PM',
    acceptedInsurance: ['HDFC ERGO', 'Star Health', 'ICICI Lombard', 'Care Health'],
    image: '/assets/generated/doctor-female-pediatric.dim_300x300.png',
    bio: 'Dr. Desai is a compassionate pediatrician dedicated to providing comprehensive care for children from infancy through adolescence. She has a special interest in developmental pediatrics.',
    qualifications: [
      'MBBS from Lady Hardinge Medical College, Delhi',
      'MD in Pediatrics from AIIMS, Delhi',
      'Member of Indian Academy of Pediatrics',
      'Certified in Neonatal Resuscitation',
    ],
    consultationFee: 1000,
  },
  {
    id: '4',
    name: 'Dr. Arjun Mehta',
    specialty: 'Dermatologist',
    rating: 4.7,
    reviewCount: 156,
    location: 'Chennai, Tamil Nadu',
    nextAvailable: 'Jan 31 at 11:00 AM',
    acceptedInsurance: ['Max Bupa', 'ICICI Lombard', 'Star Health', 'HDFC ERGO'],
    image: '/assets/generated/doctor-male-derma.dim_300x300.png',
    bio: 'Dr. Mehta is a board-certified dermatologist with expertise in medical, surgical, and cosmetic dermatology. He specializes in skin cancer detection and treatment.',
    qualifications: [
      'MBBS from Madras Medical College, Chennai',
      'MD in Dermatology from CMC, Vellore',
      'Member of Indian Association of Dermatologists',
      'Certified in Laser Dermatology',
    ],
    consultationFee: 1200,
  },
  {
    id: '5',
    name: 'Dr. Kavita Reddy',
    specialty: 'Orthopedist',
    rating: 4.8,
    reviewCount: 198,
    location: 'Hyderabad, Telangana',
    nextAvailable: 'Feb 1 at 9:00 AM',
    acceptedInsurance: ['Star Health', 'Religare', 'HDFC ERGO', 'ICICI Lombard'],
    image: '/assets/generated/doctor-female-ortho.dim_300x300.png',
    bio: 'Dr. Reddy is an orthopedic surgeon specializing in sports medicine and joint replacement. She has helped countless patients regain mobility and return to active lifestyles.',
    qualifications: [
      'MBBS from Osmania Medical College, Hyderabad',
      'MS in Orthopedics from Nizam\'s Institute of Medical Sciences',
      'Fellowship in Sports Medicine',
      'Member of Indian Orthopedic Association',
    ],
    consultationFee: 1800,
  },
  {
    id: '6',
    name: 'Dr. Vikram Singh',
    specialty: 'Primary Care',
    rating: 4.6,
    reviewCount: 142,
    location: 'Pune, Maharashtra',
    nextAvailable: 'Today at 3:00 PM',
    acceptedInsurance: ['HDFC ERGO', 'Max Bupa', 'Star Health', 'Care Health'],
    image: '/assets/generated/doctor-male-1.dim_300x300.png',
    bio: 'Dr. Singh is a dedicated family physician committed to providing personalized, comprehensive healthcare for patients of all ages. He emphasizes preventive medicine and patient education.',
    qualifications: [
      'MBBS from Armed Forces Medical College, Pune',
      'MD in General Medicine from BJ Medical College, Pune',
      'Member of Indian Medical Association',
      'Certified in Diabetes Management',
    ],
    consultationFee: 700,
  },
];

export const mockReviews: Review[] = [
  {
    id: '1',
    doctorId: '1',
    patientName: 'Rahul Verma',
    rating: 5,
    comment: 'Dr. Sharma is amazing! She took the time to listen to all my concerns and provided excellent care. Highly recommend!',
    date: '2025-01-20',
  },
  {
    id: '2',
    doctorId: '1',
    patientName: 'Meera Patel',
    rating: 5,
    comment: 'Very thorough and professional. Dr. Sharma explained everything clearly and made me feel comfortable.',
    date: '2025-01-15',
  },
  {
    id: '3',
    doctorId: '1',
    patientName: 'Amit Gupta',
    rating: 4,
    comment: 'Great doctor with excellent bedside manner. Wait time was a bit long but worth it.',
    date: '2025-01-10',
  },
  {
    id: '4',
    doctorId: '2',
    patientName: 'Sneha Iyer',
    rating: 5,
    comment: 'Dr. Kumar saved my life! His expertise in cardiology is unmatched. Forever grateful.',
    date: '2025-01-18',
  },
  {
    id: '5',
    doctorId: '2',
    patientName: 'Karthik Nair',
    rating: 5,
    comment: 'Excellent cardiologist. Very knowledgeable and takes time to explain treatment options.',
    date: '2025-01-12',
  },
  {
    id: '6',
    doctorId: '3',
    patientName: 'Pooja Malhotra',
    rating: 5,
    comment: 'Dr. Desai is wonderful with children! My kids actually look forward to their checkups now.',
    date: '2025-01-22',
  },
];
